package model;

public class AsusMonitor extends Monitor{

	public AsusMonitor(int refreshRate, int resolution) {
		super(refreshRate, resolution);
		// TODO Auto-generated constructor stub
	}

	@Override
	public void assemble() {
		// TODO Auto-generated method stub
		System.out.println("Bikin asus monitor");
	}

}
