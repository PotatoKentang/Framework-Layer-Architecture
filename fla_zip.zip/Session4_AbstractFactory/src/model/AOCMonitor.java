package model;

public class AOCMonitor extends Monitor{

	public AOCMonitor(int refreshRate, int resolution) {
		super(refreshRate, resolution);
		// TODO Auto-generated constructor stub
	}

	@Override
	public void assemble() {
		// TODO Auto-generated method stub
		
	}

}
