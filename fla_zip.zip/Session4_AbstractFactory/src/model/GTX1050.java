package model;

public class GTX1050 extends Gpu{

	public GTX1050(String name, int vram) {
		super(name, vram);
		// TODO Auto-generated constructor stub
	}

	@Override
	public void assemble() {
		// TODO Auto-generated method stub
		System.out.println("Bikin GTX1050");
	}

}
