package model;

public class RTX3090 extends Gpu{

	public RTX3090(String name, int vram) {
		super(name, vram);
		// TODO Auto-generated constructor stub
	}

	@Override
	public void assemble() {
		// TODO Auto-generated method stub
		System.out.println("Bikin gpu RTX3090");
	}

}
